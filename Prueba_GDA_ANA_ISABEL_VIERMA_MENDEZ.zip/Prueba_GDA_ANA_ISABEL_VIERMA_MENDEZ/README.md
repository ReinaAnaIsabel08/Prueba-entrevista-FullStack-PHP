Proyecto de Servicios RESTful en Lumen
Este proyecto implementa una API RESTful utilizando el framework Lumen para la gestión de clientes (Customers). El proyecto incluye servicios para registrar, consultar, y eliminar lógicamente a los clientes en el sistema. Además, se ha implementado un sistema de autenticación con tokens, protección contra inyecciones SQL, y un sistema de logging configurable.

Requisitos
PHP: Versión 7.3 o superior.
Composer: Herramienta de gestión de dependencias para PHP.
MySQL: Base de datos relacional para el almacenamiento de los datos.
Instalación
Clonar el repositorio:

bash
Copiar código
git clone <https://github.com/ReinaAnaIsabel08/Prueba-entrevista-FullStack-PHP.git>
Instalar dependencias:

bash
Copiar código
composer install
Configurar el archivo .env:

Copia el archivo .env.example a .env y configura las variables de entorno:
bash
Copiar código
cp .env.example .env
Configura los detalles de conexión a la base de datos y el valor de APP_DEBUG en false para producción.
Generar la clave de la aplicación:

bash
Copiar código
php artisan key:generate
Migrar las bases de datos:

bash
Copiar código
php artisan migrate
Ejecutar los seeders (opcional):

bash
Copiar código
php artisan db:seed
Endpoints de la API
Autenticación
POST /login: Inicia sesión y devuelve un token de autenticación. El token está encriptado en SHA1 y tiene un tiempo de vida limitado. El token se utiliza para autenticar todas las solicitudes a otros servicios.
Registro de Clientes
POST /register: Registra un nuevo cliente en el sistema. Requiere un token válido. Valida que la región y la comuna estén relacionadas y existan en la base de datos.
Consulta de Clientes
GET /customer: Consulta un cliente por dni o email. Solo devuelve clientes activos (A). Retorna los campos name, last_name, address, y las descripciones de la región y comuna.
Eliminación de Clientes
DELETE /customer: Elimina lógicamente un cliente del sistema, cambiando su estado a trash. Solo se puede eliminar a clientes activos o inactivos. Si el cliente ya está eliminado, retorna “Registro no existe”.
Seguridad
SQL Injection: Todos los servicios están protegidos contra inyecciones SQL.
Autenticación: Se utiliza un middleware para verificar el token en todas las rutas protegidas.
Logging
Se registra la información de entrada y salida de cada servicio, incluyendo la IP de origen.
Los logs de salida pueden deshabilitarse en producción configurando el parámetro APP_DEBUG=false en el archivo .env.
Documentación Adicional
Toda la información sobre la estructura del proyecto, servicios disponibles, métodos de instalación, configuración, y requisitos mínimos está detallada en este archivo.
