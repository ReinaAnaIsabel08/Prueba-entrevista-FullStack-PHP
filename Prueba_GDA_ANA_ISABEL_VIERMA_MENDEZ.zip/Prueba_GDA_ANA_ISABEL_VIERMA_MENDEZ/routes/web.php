<?php

$router->post('/login', 'AuthController@login');

$router->group(['middleware' => 'auth'], function () use ($router) {
    $router->post('/register', 'CustomerController@register');
    $router->get('/customer', 'CustomerController@show');
    $router->delete('/customer', 'CustomerController@delete');
    $router->get('/protected', 'ProtectedController@method');
});

