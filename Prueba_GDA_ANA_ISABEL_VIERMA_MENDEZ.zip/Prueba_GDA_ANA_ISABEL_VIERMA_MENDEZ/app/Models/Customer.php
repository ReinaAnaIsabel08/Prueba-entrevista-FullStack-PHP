<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use SoftDeletes;

    /**
     * La tabla asociada al modelo.
     *
     * @var string
     */
    protected $table = 'customers';

    /**
     * El nombre de la clave primaria en la tabla.
     *
     * @var string
     */
    protected $primaryKey = 'dni';

    /**
     * Indica si el modelo debe manejar marcas de tiempo.
     *
     * @var bool
     */
    public $timestamps = false;

    /**
     * Los atributos que son asignables en masa.
     *
     * @var array
     */
    protected $fillable = [
        'dni', 'id_reg', 'id_com', 'email', 'name', 'last_name', 'address', 'date_reg', 'status'
    ];

    /**
     * Los atributos que deben ser convertidos a tipos nativos.
     *
     * @var array
     */
    protected $casts = [
        'dni' => 'string',
        'id_reg' => 'integer',
        'id_com' => 'integer',
        'date_reg' => 'datetime',
    ];

    /**
     * La fecha en que se eliminó el cliente, si se aplica la eliminación suave.
     *
     * @var string
     */
    protected $dates = ['deleted_at'];

    /**
     * Relación con la región.
     */
    public function region()
    {
        return $this->belongsTo(Region::class, 'id_reg', 'id_reg');
    }

    /**
     * Relación con la comuna.
     */
    public function commune()
    {
        return $this->belongsTo(Commune::class, 'id_com', 'id_com');
    }

    /**
     * Lógica adicional al eliminar un cliente.
     *
     * @return void
     */
    protected static function booted()
    {
        static::deleting(function ($customer) {
            // Lógica adicional al eliminar un cliente
            // Por ejemplo, puedes registrar la eliminación o hacer otras comprobaciones

            // Ejemplo: Registrar la eliminación en el log
            \Log::info('Cliente eliminado', [
                'dni' => $customer->dni,
                'name' => $customer->name,
                'last_name' => $customer->last_name,
                'deleted_at' => now(),
            ]);

            // Aquí puedes agregar lógica para manejar la eliminación,
            // como notificar a otros sistemas o realizar tareas de limpieza.
        });

        static::restoring(function ($customer) {
            // Lógica adicional al restaurar un cliente
            // Por ejemplo, puedes actualizar algún campo o realizar tareas adicionales
            \Log::info('Cliente restaurado', [
                'dni' => $customer->dni,
                'name' => $customer->name,
                'last_name' => $customer->last_name,
                'restored_at' => now(),
            ]);
        });
    }
}
