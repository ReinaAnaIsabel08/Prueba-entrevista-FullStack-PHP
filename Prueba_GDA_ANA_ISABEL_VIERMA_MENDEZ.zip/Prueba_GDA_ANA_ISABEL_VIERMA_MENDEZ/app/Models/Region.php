<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Log;

class Region extends Model
{
    use SoftDeletes;

    /**
     * La tabla asociada al modelo.
     *
     * @var string
     */
    protected $table = 'regions';

    /**
     * El nombre de la clave primaria en la tabla.
     *
     * @var string
     */
    protected $primaryKey = 'id_reg';

    /**
     * Indica si el modelo debe manejar marcas de tiempo.
     *
     * @var bool
     */
    public $timestamps = false;

    /**
     * Los atributos que son asignables en masa.
     *
     * @var array
     */
    protected $fillable = [
        'id_reg', 'description'
    ];

    /**
     * Los atributos que deben ser convertidos a tipos nativos.
     *
     * @var array
     */
    protected $casts = [
        'id_reg' => 'integer',
    ];

    /**
     * La fecha en que se eliminó la región, si se aplica la eliminación suave.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * Relación con las comunas.
     */
    public function communes()
    {
        return $this->hasMany(Commune::class, 'id_reg', 'id_reg');
    }

    /**
     * Relación con los clientes.
     */
    public function customers()
    {
        return $this->hasMany(Customer::class, 'id_reg', 'id_reg');
    }

    /**
     * Lógica adicional al eliminar una región.
     *
     * @return void
     */
    protected static function booted()
    {
        static::deleting(function ($region) {
            // Verificar si la región tiene comunas o clientes antes de eliminar
            if ($region->communes()->exists() || $region->customers()->exists()) {
                throw new \Exception('No se puede eliminar la región porque tiene comunas o clientes asociados.');
            }

            // Registrar la eliminación en el log
            Log::info('Región eliminada', [
                'id_reg' => $region->id_reg,
                'description' => $region->description,
                'deleted_at' => now(),
            ]);
        });

        static::restoring(function ($region) {
            // Registrar la restauración en el log
            Log::info('Región restaurada', [
                'id_reg' => $region->id_reg,
                'description' => $region->description,
                'restored_at' => now(),
            ]);
        });
    }
}
