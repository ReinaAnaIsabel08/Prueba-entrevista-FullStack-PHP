<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Commune extends Model
{
    use SoftDeletes;

    /**
     * La tabla asociada al modelo.
     *
     * @var string
     */
    protected $table = 'communes';

    /**
     * El nombre de la clave primaria en la tabla.
     *
     * @var string
     */
    protected $primaryKey = 'id_com';

    /**
     * Indica si el modelo debe manejar marcas de tiempo.
     *
     * @var bool
     */
    public $timestamps = false;

    /**
     * Los atributos que son asignables en masa.
     *
     * @var array
     */
    protected $fillable = [
        'description',
        'id_reg',
    ];

    /**
     * Los atributos que deben ser convertidos a tipos nativos.
     *
     * @var array
     */
    protected $casts = [
        'id_com' => 'integer',
        'id_reg' => 'integer',
    ];

    /**
     * Obtén la región a la que pertenece esta comuna.
     */
    public function region()
    {
        return $this->belongsTo(Region::class, 'id_reg', 'id_reg');
    }

    /**
     * Obtén los clientes que están en esta comuna.
     */
    public function customers()
    {
        return $this->hasMany(Customer::class, 'id_com', 'id_com');
    }

    /**
     * Se ejecuta al eliminar la comuna para manejar la eliminación suave.
     *
     * @return void
     */
    protected static function booted()
    {
        static::deleting(function ($commune) {
            // Manejo adicional durante la eliminación, si es necesario.
            // Por ejemplo, podrías verificar si hay clientes asociados.
            if ($commune->customers()->count() > 0) {
                throw new \Exception('No se puede eliminar la comuna porque tiene clientes asociados.');
            }
        });
    }
}
