<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Support\Facades\Hash;

class User extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasFactory;

    /**
     * Los atributos que son asignables en masa.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * Los atributos ocultos para los arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * Los atributos que deben ser convertidos a tipos nativos.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Hash el password antes de guardar el modelo.
     *
     * @param  string  $value
     * @return void
     */
    public function setPasswordAttribute($value)
    {
        if (!empty($value)) {
            $this->attributes['password'] = Hash::make($value);
        }
    }

    /**
     * Verifica si el usuario tiene un rol específico.
     *
     * @param  string  $role
     * @return bool
     */
    public function hasRole($role)
    {
        // Supone que hay una relación con un modelo de roles
        return $this->roles()->where('name', $role)->exists();
    }

    /**
     * Obtiene los roles del usuario.
     */
    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

    /**
     * Configura el nombre de la tabla para el modelo.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * La clave primaria de la tabla.
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * Indica si el modelo debe manejar marcas de tiempo.
     *
     * @var bool
     */
    public $timestamps = true;

    /**
     * Lógica adicional al guardar un usuario.
     *
     * @return void
     */
    protected static function booted()
    {
        static::creating(function ($user) {
            // Lógica adicional al crear un usuario
            \Log::info('Usuario creado', [
                'id' => $user->id,
                'email' => $user->email,
                'created_at' => now(),
            ]);
        });

        static::updating(function ($user) {
            // Lógica adicional al actualizar un usuario
            \Log::info('Usuario actualizado', [
                'id' => $user->id,
                'email' => $user->email,
                'updated_at' => now(),
            ]);
        });
    }
}
