<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterCustomerRequest extends FormRequest
{
    /**
     * Determina si el usuario está autorizado para hacer esta solicitud.
     *
     * @return bool
     */
    public function authorize()
    {
        // Aquí puedes agregar lógica para autorizar la solicitud.
        // Por ejemplo, verificar permisos del usuario autenticado.
        // Para simplicidad, se establece en true.
        return true;
    }

    /**
     * Obtén las reglas de validación que se aplican a la solicitud.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'dni' => 'required|string|size:8|unique:customers,dni', // DNI requerido, debe tener 8 caracteres y ser único
            'id_reg' => 'required|exists:regions,id_reg', // ID de la región requerido y debe existir en la tabla 'regions'
            'id_com' => 'required|exists:communes,id_com,id_reg,' . $this->input('id_reg'), // ID de la comuna requerido, debe existir en la tabla 'communes' y estar relacionado con la región proporcionada
            'email' => 'required|email|unique:customers,email', // Correo electrónico requerido, debe ser único
            'name' => 'required|string|max:45', // Nombre requerido, debe ser una cadena con máximo 45 caracteres
            'last_name' => 'required|string|max:45', // Apellido requerido, debe ser una cadena con máximo 45 caracteres
            'address' => 'nullable|string|max:255', // Dirección opcional, debe ser una cadena con máximo 255 caracteres
        ];
    }

    /**
     * Mensajes de error personalizados para las reglas de validación.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'dni.required' => 'El DNI es obligatorio.',
            'dni.string' => 'El DNI debe ser una cadena de caracteres.',
            'dni.size' => 'El DNI debe tener exactamente :size caracteres.',
            'dni.unique' => 'El DNI ya está registrado.',
            'id_reg.required' => 'El ID de la región es obligatorio.',
            'id_reg.exists' => 'La región especificada no existe.',
            'id_com.required' => 'El ID de la comuna es obligatorio.',
            'id_com.exists' => 'La comuna especificada no existe.',
            'email.required' => 'El correo electrónico es obligatorio.',
            'email.email' => 'El correo electrónico debe ser una dirección válida.',
            'email.unique' => 'El correo electrónico ya está registrado.',
            'name.required' => 'El nombre es obligatorio.',
            'name.string' => 'El nombre debe ser una cadena de caracteres.',
            'name.max' => 'El nombre no debe superar los :max caracteres.',
            'last_name.required' => 'El apellido es obligatorio.',
            'last_name.string' => 'El apellido debe ser una cadena de caracteres.',
            'last_name.max' => 'El apellido no debe superar los :max caracteres.',
            'address.string' => 'La dirección debe ser una cadena de caracteres.',
            'address.max' => 'La dirección no debe superar los :max caracteres.',
        ];
    }

    /**
     * Define los atributos de los campos que se utilizarán en los mensajes de error.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'dni' => 'DNI',
            'id_reg' => 'ID de región',
            'id_com' => 'ID de comuna',
            'email' => 'correo electrónico',
            'name' => 'nombre',
            'last_name' => 'apellido',
            'address' => 'dirección',
        ];
    }
}
