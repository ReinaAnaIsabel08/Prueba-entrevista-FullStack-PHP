<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DeleteCustomerRequest extends FormRequest
{
    /**
     * Determina si el usuario está autorizado para hacer esta solicitud.
     *
     * @return bool
     */
    public function authorize()
    {
        // Aquí puedes agregar lógica para autorizar la solicitud.
        // Por ejemplo, podrías verificar si el usuario tiene permisos para eliminar un cliente.
        // Se establece en true para permitir la solicitud para esta demostración.
        return true;
    }

    /**
     * Obtén las reglas de validación que se aplican a la solicitud.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // Se requiere el DNI o ID del cliente para la eliminación.
            // Aquí estamos utilizando un campo 'dni' con una validación más flexible.
            'dni' => [
                'required',
                'string',
                'size:8',
                'regex:/^[0-9]{8}$/', // Validar que el DNI contenga solo dígitos
            ],
            // Si en lugar de DNI se usa un ID, cambia la regla a 'id' y ajusta la validación.
        ];
    }

    /**
     * Mensajes de error personalizados para las reglas de validación.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'dni.required' => 'El campo DNI es obligatorio y debe proporcionarse para realizar la eliminación.',
            'dni.string' => 'El DNI debe ser una cadena de caracteres.',
            'dni.size' => 'El DNI debe tener exactamente :size caracteres.',
            'dni.regex' => 'El DNI debe contener únicamente dígitos.',
        ];
    }
}
