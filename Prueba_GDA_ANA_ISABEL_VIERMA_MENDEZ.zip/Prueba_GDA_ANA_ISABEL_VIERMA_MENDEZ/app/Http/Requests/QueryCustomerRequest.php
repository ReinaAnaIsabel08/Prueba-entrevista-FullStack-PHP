<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class QueryCustomerRequest extends FormRequest
{
    /**
     * Determina si el usuario está autorizado para hacer esta solicitud.
     *
     * @return bool
     */
    public function authorize()
{

    if (!auth()->check()) {
        return false;
    }
    return true;
}

    /**
     * Obtén las reglas de validación que se aplican a la solicitud.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // Al menos uno de los dos campos debe ser proporcionado.
            'dni' => 'nullable|string|size:8', // Ejemplo para DNI de 8 caracteres
            'email' => 'nullable|email',
        ];
    }

    /**
     * Mensajes de error personalizados para las reglas de validación.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'dni.size' => 'El DNI debe tener exactamente :size caracteres.',
            'email.email' => 'El correo electrónico debe ser una dirección de correo válida.',
            'dni.string' => 'El DNI debe ser una cadena de caracteres.',
            'dni.required_without' => 'Debes proporcionar uno de los siguientes campos: DNI o correo electrónico.',
            'email.required_without' => 'Debes proporcionar uno de los siguientes campos: DNI o correo electrónico.',
        ];
    }

    /**
     * Define los atributos de los campos que se utilizarán en los mensajes de error.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'dni' => 'DNI',
            'email' => 'correo electrónico',
        ];
    }

    /**
     * Configura la validación condicional para asegurar que al menos uno de los campos esté presente.
     *
     * @return array
     */
    protected function prepareForValidation()
    {
        $this->merge([
            'dni' => $this->input('dni') ? trim($this->input('dni')) : null,
            'email' => $this->input('email') ? trim($this->input('email')) : null,
        ]);
    }
}
