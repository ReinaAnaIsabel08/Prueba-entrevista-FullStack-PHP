<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AuthController extends Controller
{
    /**
     * Handle login and generate JWT token.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        // Validar los datos de entrada con mensajes personalizados
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string|min:8',
        ], [
            'email.required' => 'El campo email es obligatorio.',
            'email.email' => 'El email debe ser una dirección de correo válida.',
            'password.required' => 'El campo contraseña es obligatorio.',
            'password.min' => 'La contraseña debe tener al menos 8 caracteres.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        $credentials = $request->only('email', 'password');

        try {
            // Intentar generar el token con las credenciales proporcionadas
            if (!$token = JWTAuth::attempt($credentials)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Credenciales inválidas'
                ], 401);
            }

            // Retornar el token generado
            return response()->json([
                'success' => true,
                'token' => $token,
                'expires_in' => 3600, // El tiempo de expiración del token en segundos
            ], 200);

        } catch (JWTException $e) {
            // Registrar el error y retornar una respuesta adecuada
            Log::error('Error al crear el token JWT', ['exception' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'No se pudo crear el token'
            ], 500);
        }
    }

    /**
     * Handle logout and invalidate the JWT token.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout(Request $request)
    {
        // Validar el token en la solicitud
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Token no proporcionado.',
            ], 400);
        }

        try {
            // Invalidar el token
            JWTAuth::setToken($token)->invalidate();

            return response()->json([
                'success' => true,
                'message' => 'Sesión cerrada exitosamente.',
            ], 200);

        } catch (JWTException $e) {
            // Registrar el error y retornar una respuesta adecuada
            Log::error('Error al invalidar el token JWT', ['exception' => $e->getMessage()]);

            return response()->json([
                'success' => false,
                'message' => 'Error al cerrar sesión'
            ], 500);
        }
    }
}
