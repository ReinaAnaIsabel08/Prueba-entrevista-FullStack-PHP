<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class Controller extends BaseController
{
    /**
     * Manejar y registrar errores de forma centralizada.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Exception $exception
     * @return \Illuminate\Http\JsonResponse
     */
    protected function handleException(Request $request, \Exception $exception)
    {
        // Registra el error en el sistema de logs con detalles completos
        Log::error('Error en la solicitud:', [
            'url' => $request->url(),
            'input' => $request->all(),
            'exception_message' => $exception->getMessage(),
            'exception_file' => $exception->getFile(),
            'exception_line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString(),
        ]);

        // Devuelve una respuesta JSON con el mensaje de error y código de estado 500
        return response()->json([
            'success' => false,
            'message' => 'Ocurrió un error inesperado. Por favor, inténtelo de nuevo más tarde.',
        ], 500);
    }

    /**
     * Método para validar las entradas del usuario.
     *
     * @param array $rules
     * @param \Illuminate\Http\Request $request
     * @param array $customMessages
     * @return \Illuminate\Http\JsonResponse|null
     */
    protected function validateRequest(array $rules, Request $request, array $customMessages = [])
    {
        $validator = Validator::make($request->all(), $rules, $customMessages);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        return null;
    }
}
