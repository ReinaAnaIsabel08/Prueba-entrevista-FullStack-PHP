<?php

namespace App\Http\Controllers;

use App\Http\Requests\DeleteCustomerRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Models\Customer;

class CustomerController extends Controller
{
    /**
     * Elimina un cliente basado en el DNI.
     *
     * @param  \App\Http\Requests\DeleteCustomerRequest  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete(DeleteCustomerRequest $request): JsonResponse
    {
        $dni = $request->input('dni');

        // Encuentra el cliente por DNI
        $customer = Customer::where('dni', $dni)->first();

        if (!$customer) {
            return response()->json([
                'success' => false,
                'message' => 'Cliente no encontrado con el DNI proporcionado.',
            ], 404);
        }

        // Elimina el cliente
        $customer->delete();

        return response()->json([
            'success' => true,
            'message' => 'Cliente eliminado exitosamente.',
        ], 200);
    }

    /**
     * Registrar un nuevo cliente.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function storeCustomer(Request $request): JsonResponse
    {
        // Definir las reglas de validación y mensajes personalizados
        $rules = [
            'dni' => 'required|string|unique:customers,dni',
            'id_reg' => 'required|exists:regions,id_reg',
            'id_com' => 'required|exists:communes,id_com,id_reg,' . $request->input('id_reg'),
            'email' => 'required|email|unique:customers,email',
            'name' => 'required|string|max:45',
            'last_name' => 'required|string|max:45',
            'address' => 'nullable|string|max:255',
        ];

        $messages = [
            'dni.unique' => 'El DNI ya está registrado.',
            'id_reg.exists' => 'La región no existe.',
            'id_com.exists' => 'La comuna no existe.',
            'email.unique' => 'El correo electrónico ya está registrado.',
            'name.required' => 'El nombre es obligatorio.',
            'last_name.required' => 'El apellido es obligatorio.',
        ];

        // Validar los datos de entrada
        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        // Inserción segura utilizando Eloquent
        $customer = Customer::create([
            'dni' => $request->input('dni'),
            'id_reg' => $request->input('id_reg'),
            'id_com' => $request->input('id_com'),
            'email' => $request->input('email'),
            'name' => $request->input('name'),
            'last_name' => $request->input('last_name'),
            'address' => $request->input('address'),
            'date_reg' => now(),
            'status' => 'A',
        ]);

        return response()->json([
            'success' => true,
            'customer' => $customer
        ], 201);
    }

    /**
     * Consultar un cliente por DNI o email.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getCustomer(Request $request): JsonResponse
    {
        // Definir las reglas de validación y mensajes personalizados
        $rules = [
            'dni' => 'required_without:email|nullable|string',
            'email' => 'required_without:dni|nullable|email',
        ];

        $messages = [
            'dni.required_without' => 'Debe proporcionar DNI o correo electrónico.',
            'email.required_without' => 'Debe proporcionar DNI o correo electrónico.',
        ];

        // Validar los parámetros de entrada
        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        // Consultar cliente utilizando Query Builder
        $customer = Customer::where('status', 'A')
            ->when($request->input('dni'), function ($query, $dni) {
                $query->where('dni', $dni);
            })
            ->when($request->input('email'), function ($query, $email) {
                $query->where('email', $email);
            })
            ->with(['region', 'commune'])
            ->first();

        if ($customer) {
            return response()->json([
                'success' => true,
                'customer' => [
                    'name' => $customer->name,
                    'last_name' => $customer->last_name,
                    'address' => $customer->address ?? null,
                    'region' => $customer->region->description,
                    'commune' => $customer->commune->description,
                ]
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Cliente no encontrado'
            ], 404);
        }
    }

    /**
     * Eliminar lógicamente un cliente.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $dni
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteCustomer(Request $request, $dni): JsonResponse
    {
        // Validar la existencia del cliente
        $customer = Customer::where('dni', $dni)
            ->whereIn('status', ['A', 'I'])
            ->first();

        if (!$customer) {
            return response()->json([
                'success' => false,
                'message' => 'Registro no existe'
            ], 404);
        }

        // Actualizar el estado del cliente a 'trash'
        $customer->update(['status' => 'trash']);

        return response()->json([
            'success' => true,
            'message' => 'Cliente eliminado lógicamente'
        ], 200);
    }
}
