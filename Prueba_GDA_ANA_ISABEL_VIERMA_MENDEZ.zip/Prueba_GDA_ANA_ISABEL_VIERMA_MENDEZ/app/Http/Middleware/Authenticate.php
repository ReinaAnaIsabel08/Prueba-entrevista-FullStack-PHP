<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Factory as Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\JsonResponse;

class Authenticate
{
    /**
     * The authentication guard factory instance.
     *
     * @var \Illuminate\Contracts\Auth\Factory
     */
    protected $auth;

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Contracts\Auth\Factory  $auth
     * @return void
     */
    public function __construct(Auth $auth)
    {
        $this->auth = $auth;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle(Request $request, Closure $next, $guard = null)
    {
        // Verificar si el usuario está autenticado
        if ($this->auth->guard($guard)->guest()) {
            // Registrar el intento de acceso no autorizado
            $this->logUnauthorizedAttempt($request);

            // Retornar una respuesta JSON más detallada
            return $this->unauthorizedResponse();
        }

        return $next($request);
    }

    /**
     * Return an unauthorized response.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function unauthorizedResponse(): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => 'No autorizado. Se requiere autenticación.',
        ], JsonResponse::HTTP_UNAUTHORIZED);
    }

    /**
     * Log unauthorized attempt details.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    protected function logUnauthorizedAttempt(Request $request): void
    {
        Log::warning('Intento de acceso no autorizado', [
            'url' => $request->fullUrl(), // Utiliza fullUrl para obtener la URL completa
            'method' => $request->method(), // Añade el método HTTP
            'input' => $request->except('password'), // Excluir datos sensibles
            'ip' => $request->ip(),
            'user_agent' => $request->header('User-Agent'), // Añade el User-Agent
        ]);
    }
}
