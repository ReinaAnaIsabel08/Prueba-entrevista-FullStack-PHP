<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AuthMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        try {
            $token = $this->extractToken($request);

            // Validar el token
            $user = JWTAuth::setToken($token)->authenticate();

            if (!$user) {
                return $this->unauthorizedResponse();
            }

            // Continuar con la solicitud
            return $next($request);

        } catch (JWTException $e) {
            // Registrar el intento de acceso con token inválido
            $this->logInvalidTokenAttempt($request);

            // Retornar una respuesta JSON más detallada
            return $this->unauthorizedResponse();
        }
    }

    /**
     * Extract the token from the Authorization header.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return string|null
     */
    private function extractToken(Request $request): ?string
    {
        $header = $request->header('Authorization');

        if ($header && preg_match('/^Bearer\s+(.*)$/i', $header, $matches)) {
            return $matches[1];
        }

        return null;
    }

    /**
     * Return an unauthorized response.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    private function unauthorizedResponse()
    {
        return response()->json([
            'success' => false,
            'message' => 'Token inválido o expirado.',
        ], 401);
    }

    /**
     * Log an invalid token attempt.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    private function logInvalidTokenAttempt(Request $request)
    {
        Log::warning('Intento de acceso con token inválido', [
            'url' => $request->fullUrl(),
            'method' => $request->method(),
            'ip' => $request->ip(),
            'user_agent' => $request->header('User-Agent'),
        ]);
    }
}

