<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LogMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Solo registrar información si APP_DEBUG está habilitado
        if (config('app.debug')) {
            // Registro de información de entrada
            Log::info('Request received', [
                'ip' => $request->ip(),
                'method' => $request->method(),
                'url' => $request->fullUrl(),
                'headers' => $request->headers->all(),
                'payload' => $this->sanitizeData($request->all())
            ]);
        }

        // Pasar la solicitud al siguiente middleware/handler
        $response = $next($request);

        // Solo registrar información si APP_DEBUG está habilitado
        if (config('app.debug')) {
            // Registro de información de salida
            Log::info('Response sent', [
                'ip' => $request->ip(),
                'status' => $response->status(),
                'headers' => $response->headers->all(),
                'body' => $this->sanitizeData($response->getContent())
            ]);
        }

        return $response;
    }

    /**
     * Sanitizar datos para evitar registrar información sensible.
     *
     * @param  mixed  $data
     * @return mixed
     */
    private function sanitizeData($data)
    {
        // Puedes ajustar esto según el tipo de datos y las necesidades de sanitización
        // Ejemplo: Eliminar claves que contienen información sensible
        if (is_array($data)) {
            unset($data['password']);
            unset($data['credit_card']);
        } elseif (is_string($data)) {
            // Si es un JSON, podemos intentar convertirlo y sanitizar
            $data = json_decode($data, true);
            if (is_array($data)) {
                unset($data['password']);
                unset($data['credit_card']);
                $data = json_encode($data);
            }
        }

        return $data;
    }
}
