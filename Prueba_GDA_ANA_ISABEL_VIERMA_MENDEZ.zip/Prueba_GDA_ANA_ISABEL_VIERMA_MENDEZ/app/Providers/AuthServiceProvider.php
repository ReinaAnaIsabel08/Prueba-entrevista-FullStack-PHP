<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class AuthServiceProvider extends ServiceProvider
{
    public function register()
    {
        // Registrar servicios adicionales relacionados con la autenticación aquí
    }

    public function boot()
    {
        $this->defineTokenAuth();
    }

    protected function defineTokenAuth()
    {
        Auth::viaRequest('api', function ($request) {
            $apiToken = $request->bearerToken();

            if ($apiToken) {
                $user = User::where('api_token', $apiToken)->first();

                if ($user && $this->isValidToken($apiToken, $user)) {
                    return $user;
                }
            }

            return null;
        });
    }

    protected function isValidToken($token, $user)
    {
        if ($user->token_expires_at && $user->token_expires_at->isPast()) {
            Log::warning('Token expirado', [
                'user_id' => $user->id,
                'token' => $token,
            ]);
            return false;
        }

        return true;
    }
}
