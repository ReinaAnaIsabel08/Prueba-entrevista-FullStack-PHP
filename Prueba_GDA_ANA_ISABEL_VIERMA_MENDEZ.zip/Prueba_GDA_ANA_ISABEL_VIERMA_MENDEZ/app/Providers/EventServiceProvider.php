<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Event;
use Illuminate\Log\Logger;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        \App\Events\CustomerRegistered::class => [
            \App\Listeners\SendWelcomeEmail::class,
        ],
        \App\Events\RegionUpdated::class => [
            \App\Listeners\NotifyRegionUpdate::class,
        ],
    ];

    public function boot()
    {
        parent::boot();

        Event::listen(function ($event) {
            $this->logEvent($event);
        });
    }

    public function register()
    {
    }

    public function shouldDiscoverEvents()
    {
        return false;
    }

    protected function logEvent($event)
    {
        /** @var Logger $logger */
        $logger = app(Logger::class);

        $logger->info('Evento disparado', [
            'event' => get_class($event),
            'data' => $this->extractEventData($event),
        ]);
    }

    protected function extractEventData($event)
    {
        return method_exists($event, 'toArray') ? $event->toArray() : [];
    }
}
