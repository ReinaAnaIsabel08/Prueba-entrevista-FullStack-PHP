<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Pagination\Paginator;
use Illuminate\Database\Eloquent\Model;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Registra cualquier servicio de aplicación.
     *
     * @return void
     */
    public function register()
    {
        // Registrar otros servicios o bindings en el contenedor de servicios si es necesario
        // Por ejemplo, registrar servicios personalizados o binding de interfaces a implementaciones.
    }

    /**
     * Realiza cualquier configuración de servicio de aplicación.
     *
     * @return void
     */
    public function boot()
    {
        // Configura el nombre de la tabla en el esquema de la base de datos
        Schema::defaultStringLength(191);

        // Configura los nombres de las tablas relacionadas para relaciones polimórficas
        Relation::morphMap([
            'customers' => 'App\Models\Customer',
            'regions' => 'App\Models\Region',
            'communes' => 'App\Models\Commune',
        ]);

        // Establece el estilo de paginación por defecto a Bootstrap
        Paginator::useBootstrap();

        // Configura el comportamiento de los modelos Eloquent para prevenir timestamps en modelos específicos
        Model::preventSilentlyDiscardingAttributes();

        // Configura el logging para capturar consultas SQL en el entorno local
        if ($this->app->environment('local')) {
            \DB::listen(function ($query) {
                Log::debug('SQL Query:', [
                    'query' => $query->sql,
                    'bindings' => $query->bindings,
                    'time' => $query->time,
                ]);
            });
        }

        // Configura los valores predeterminados para el timezone y locale de la aplicación
        config(['app.timezone' => 'UTC']);
        config(['app.locale' => 'en']);

        // Agrega validación adicional de las migraciones
        $this->loadMigrationsFrom(database_path('migrations'));
    }
}
