<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

abstract class Job implements ShouldQueue
{
    use InteractsWithQueue, Queueable, SerializesModels;

    /**
     * El número máximo de reintentos para este trabajo.
     *
     * @var int
     */
    public $tries = 5;

    /**
     * El tiempo en segundos que se debe esperar antes de intentar el trabajo nuevamente.
     *
     * @var int
     */
    public $backoff = 60; // Reintentar después de 60 segundos

    /**
     * Configura el comportamiento del trabajo cuando se hace disponible en la cola.
     *
     * @return array
     */
    public function middleware()
    {
        return [
            // Puedes agregar middleware específico para trabajos en cola aquí.
            // Ejemplo: \Illuminate\Queue\Middleware\ThrottlesExceptions::class
        ];
    }

    /**
     * Configura el nombre de la cola para este trabajo.
     *
     * @return string
     */
    public function queue()
    {
        // Usa el nombre de la cola especificado en el trabajo hijo si está disponible.
        return property_exists($this, 'queue') ? $this->queue : 'default';
    }

    /**
     * Manejar el trabajo si se produce una excepción.
     *
     * @param  \Throwable  $exception
     * @return void
     */
    public function failed(\Throwable $exception)
    {
        // Registrar el error para el trabajo fallido
        Log::error('Trabajo fallido', [
            'exception' => $exception->getMessage(),
            'job' => static::class,
            'context' => [
                'job_id' => $this->job->getJobId(), // ID del trabajo fallido
                'queue' => $this->queue(), // Nombre de la cola
            ],
        ]);

        // Aquí puedes agregar lógica adicional para manejar los errores, como notificaciones
        // Ejemplo: Notificar al equipo de soporte o realizar alguna acción correctiva.
    }

    /**
     * Configura el tiempo de espera para ejecutar el trabajo.
     *
     * @return \Illuminate\Support\Carbon
     */
    public function retryUntil()
    {
        // Define el tiempo hasta que el trabajo debe ser reintentado dinámicamente
        return now()->addMinutes($this->getRetryDuration());
    }

    /**
     * Define el tiempo de espera antes del siguiente reintento.
     *
     * @return int
     */
    protected function getRetryDuration()
    {
        // Puedes ajustar esta lógica para determinar dinámicamente el tiempo de reintento.
        // Por ejemplo, puedes usar un enfoque exponencial o basado en la configuración.
        return $this->backoff;
    }
}
