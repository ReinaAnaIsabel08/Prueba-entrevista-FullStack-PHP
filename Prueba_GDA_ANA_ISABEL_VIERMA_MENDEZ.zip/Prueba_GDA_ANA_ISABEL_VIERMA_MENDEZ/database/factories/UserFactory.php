<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class UserFactory extends Factory
{
    protected $model = User::class;

    public function definition()
    {
        return [
            'name' => $this->faker->name,
            'email' => $this->faker->unique()->safeEmail,
            'password' => bcrypt('password'),
            'api_token' => $this->faker->uuid,
            'token_expires_at' => $this->faker->optional()->dateTimeBetween('now', '+1 year'),
        ];
    }

    public function active()
    {
        return $this->state([
            'status' => 'active',
        ]);
    }

    public function inactive()
    {
        return $this->state([
            'status' => 'inactive',
        ]);
    }

    public function admin()
    {
        return $this->state([
            'role' => 'admin',
        ]);
    }
}
