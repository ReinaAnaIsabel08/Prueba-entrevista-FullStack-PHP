<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCommunesTable extends Migration
{
    public function up()
    {
        Schema::create('communes', function (Blueprint $table) {
            $table->id('id_com');
            $table->unsignedBigInteger('id_reg');
            $table->string('description', 90)->unique();
            $table->enum('status', ['active', 'inactive', 'trash'])->default('active');
            $table->timestamps(); // Añadido para manejar created_at y updated_at
            $table->softDeletes(); // Añadido para manejar eliminación suave

            $table->foreign('id_reg')
                ->references('id_reg')
                ->on('regions')
                ->onDelete('cascade'); // Eliminar en cascada

            $table->unique(['id_com', 'id_reg']); // Combinación única de id_com y id_reg
        });
    }

    public function down()
    {
        Schema::dropIfExists('communes');
    }
}
