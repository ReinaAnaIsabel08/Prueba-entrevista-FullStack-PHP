<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomersTable extends Migration
{
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->string('dni', 45);
            $table->unsignedBigInteger('id_reg');
            $table->unsignedBigInteger('id_com');
            $table->string('email', 120)->unique();
            $table->string('name', 45);
            $table->string('last_name', 45);
            $table->string('address', 255)->nullable();
            $table->dateTime('date_reg');
            $table->enum('status', ['active', 'inactive', 'trash'])->default('active');
            $table->timestamps(); // Añadido para manejar created_at y updated_at
            $table->softDeletes(); // Añadido para manejar eliminación suave

            $table->primary(['dni', 'id_reg', 'id_com']);

            $table->foreign('id_reg')
                ->references('id_reg')
                ->on('regions')
                ->onDelete('cascade'); // Eliminar en cascada si la región es eliminada

            $table->foreign('id_com')
                ->references('id_com')
                ->on('communes')
                ->onDelete('cascade'); // Eliminar en cascada si la comuna es eliminada
        });
    }

    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
